import os 


os.system('cls')

from classe_livro.metodos import livro1,livro2,livro3

livro1.exibir_info()
livro2.exibir_info()
livro3.exibir_info()
